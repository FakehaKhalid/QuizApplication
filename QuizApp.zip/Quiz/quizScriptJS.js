var currentQuestion = 0;
var score = 0;
 

var questionElement = document.getElementById('question');
var radio1 = document.getElementById('opt1');
var radio2 = document.getElementById('opt2');
var radio3 = document.getElementById('opt3');
var radio4 = document.getElementById('opt4');
var js = document.getElementById('quizContainer');
var nextButton = document.getElementById('nextBtn');
var finalresult = document.getElementById('result');
 

var totalQustions = questionsjs.length;
function loadQuestion(questionIndex)
{
    var num = questionsjs[questionIndex];
    questionElement.textContent = (questionIndex + 1) + '.' + num.question;
    radio1.textContent = num.option1;
    radio2.textContent = num.option2;
    radio3.textContent = num.option3;
    radio4.textContent = num.option4;
};

function loadNextQuestion(){
    var selectedoption = document.querySelector('input[type=radio]:checked');
    if(!selectedoption){
        alert("Please select your answer");
        return;
    }
    var answer = selectedoption.value;
    if(questionsjs[currentQuestion].answer == answer){
        score += 2;
        alert("correct answer!");
    }
    selectedoption.checked = false;
    currentQuestion++;
    if(currentQuestion == totalQustions -1){
        nextButton.textContent = 'Finish'; 
    }
    if(currentQuestion == totalQustions){
        quizContainer.style.display= 'none';
        
        finalresult.style.display= '';
        finalresult.textContent = 'Your Score:'+score;
        return;
    }
    loadQuestion(currentQuestion);
}
loadQuestion(currentQuestion);
