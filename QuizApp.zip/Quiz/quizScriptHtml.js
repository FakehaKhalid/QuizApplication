var currentQuestion = 0;
var score = 0;
 

var questionElement = document.getElementById('question');
var radio1 = document.getElementById('opt1');
var radio2 = document.getElementById('opt2');
var radio3 = document.getElementById('opt3');
var radio4 = document.getElementById('opt4');
var html = document.getElementById('quizContainer');
var nextButton = document.getElementById('nextBtn');
var finalresult = document.getElementById('result');

 var nextButton2 = document.getElementById('nextBtn2'); 


var totalQustions = questionshtml.length;
function loadQuestion(questionIndex)
{
    var num = questionshtml[questionIndex];
    questionElement.textContent = (questionIndex + 1) + '.' + num.question;
    radio1.textContent = num.option1;
    radio2.textContent = num.option2;
    radio3.textContent = num.option3;
    radio4.textContent = num.option4;
};

function loadNextQuestion(){
    var selectedoption = document.querySelector('input[type=radio]:checked');
    if(!selectedoption){
        alert("Please select your answer");
        return;
    }
    var answer = selectedoption.value;
    if(questionshtml[currentQuestion].answer == answer){
        score += 2;
        alert("correct answer!");
    }
    
    selectedoption.checked = false;
    currentQuestion++;
    
    if(currentQuestion == totalQustions -1){
        nextButton.textContent = 'Finish'; 
    }

    if(currentQuestion == totalQustions){
        quizContainer.style.display= 'none';
        
        finalresult.style.display= '';
        finalresult.textContent = 'Your Score:'+score;
        
        
        return;

    }
    
    
    loadQuestion(currentQuestion);
}

loadQuestion(currentQuestion);


        

