var questionshtml = [
    {question: "What does HTML stand for?",
      "option1": "home tool markup language",
      "option2": "hyper tool makeup language",
      "option3": "hyper text markup language",
      "option4": "None of the above",
    "answer": "3"
},{
    question: "Choose the correct HTML element for the largest heading:",
      "option1": "<h1>",
      "option2": "<heading>",
      "option3": "<hr>",
      "option4": "None of the above",
    "answer": "1"
  },{
      question: "What is the correct HTML element for inserting a line break?",
      "option1": "<break>",
      "option2": "<lineBr>",
      "option3": "<br>",
      "option4": "None of the above",
    "answer": "3"
  },
  {
    question: "Choose the correct HTML element to define emphasized text",
      "option1": "<i>",
      "option2": "<imp>",
      "option3": "<em>",
      "option4": "None of the above",
      "answer" : "3"
  },
  {
    question: "Which HTML element defines the title of a document?",
    
      "option1": "<meta>",
      "option2": "<head>",
      "option3": "<title>",
      "option4": "none of the above",
    "answer": "3"
  }
];


var questionscss = [
    {question: "What does CSS stand for?",
      "option1": "computer Style Sheets",
      "option2": "Colorful Style Sheets",
      "option3": "Cascading Style Sheets",
      "option4": "None of the above",
    "answer": "3"
},{
    question: "Where in an HTML document is the correct place to refer to an external style sheet?",
      "option1": "In the <head> section",
      "option2": "In the <body> section",
      "option3": "At the end of the document",
      "option4": "None of the above",
    "answer": "1"
  },{
      question: "Which HTML tag is used to define an internal style sheet?",
      "option1": "<script>",
      "option2": "<css>",
      "option3": "<style>",
      "option4": "None of the above",
    "answer": "3"
  },
  {
    question: "Which CSS property is used to change the text color of an element?",
      "option1": "text-color",
      "option2": "color",
      "option3": "fgcolor",
      "option4": "None of the above",
      "answer" : "2"
  },
  {
    question: "Which property is used to change the font of an element?",
    
      "option1": "font-style",
      "option2": "font-family",
      "option3": "font-weight",
      "option4": "none of the above",
    "answer": "2"
  }
];



var questionsjs = [
    {question: "How to write an IF statement in JavaScript?",
      "option1": "if (i == 5)",
      "option2": "if i == 5 then",
      "option3": "if i = 5 then",
      "option4": "None of the above",
    "answer": "1"
},{
    question: "How does a FOR loop start?",
      "option1": "for i = 1 to 5",
      "option2": "for (i <= 5; i++)",
      "option3": "for (i = 0; i <= 5; i++)",
      "option4": "None of the above",
    "answer": "3"
  },{
      question: "How can you add a comment in a JavaScript?",
      "option1": "//This is a comment",
      "option2": "<!--This is a comment-->",
      "option3": "/This is a comment/",
      "option4": "None of the above",
    "answer": "1"
  },
  {
    question: "How do you declare a JavaScript variable?",
      "option1": "variable carName;",
      "option2": "v carName;",
      "option3": "var carName;",
      "option4": "None of the above",
      "answer" : "3"
  },
  {
    question: " Inside which HTML element do we put the JavaScript?",
    
      "option1": "<javascript>",
      "option2": "<scripting>",
      "option3": "<script>",
      "option4": "none of the above",
    "answer": "3"
  }
];

