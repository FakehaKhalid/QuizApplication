var userName = document.getElementById("username");
var password = document.getElementById("password");
 function login(){
     if(userName.value == "Fakeha" && password.value == "12345"){
         location='welcome.html'
     }
     else if(userName.value=="sidra" && password.value=="22345"){
         location='welcome.html'
        
     }
    
     else if(userName.value=="bisma" && password.value=="welcome"){
         location='welcome.html'
     }
     else {
      alert("Incorrect details");
     }
 }

 var userName1=document.getElementById("user-name");
 var email1=document.getElementById("email");
 var password1=document.getElementById("pass");

 function signup(){
 if(userName1.value== "" || email1.value=="" || password1.value==""){
 alert("please fill all the fields");
 }
 else{
location='welcome.html';
 }
 }

 